import Page1 from './Page1';
import Connexion from './Connexion';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Like from './Like';
import ShoppingCart from './ShoppingCart';



export default function App() {

  const Stack = createNativeStackNavigator();

    return (
        <NavigationContainer>
          <Stack.Navigator>
            <Stack.Screen name="Connexion" component={Connexion} options={{ headerShown: false }}/>
            <Stack.Screen name="Page1" component={Page1} options={{ headerShown: false }}/>
            <Stack.Screen name="Like" component={Like} options={{ headerShown: false }}/>

          </Stack.Navigator>
        </NavigationContainer>
    );
}